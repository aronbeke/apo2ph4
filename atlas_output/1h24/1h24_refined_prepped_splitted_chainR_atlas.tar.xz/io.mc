##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Fri Jul  5 16:30:36 2024

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path out.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing gcent...
PBEparm_parseToken:  trying gcent...
MGparm_parseToken:  trying gcent...
NOsh_parseMG:  Parsing grid...
PBEparm_parseToken:  trying grid...
MGparm_parseToken:  trying grid...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 0.
NOsh:  nlev = 5, dime = (193, 193, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2518 atoms
Valist_getStatistics:  Max atom coordinate:  (45.63, 90.428, 102.643)
Valist_getStatistics:  Min atom coordinate:  (-3.321, 38.709, 49.505)
Valist_getStatistics:  Molecule center:  (21.1545, 64.5685, 76.074)
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 0 (1)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 33.7149
Vpbe_ctor2:  solute dimensions = 52.075 x 54.496 x 55.955
Vpbe_ctor2:  solute charge = -3
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.102998
Vpbe_ctor2:  Debye length = 9.70891
Vpbe_ctor2:  zkappa2 = 0.84869
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (62.4694, 65.2374, 66.6564)
Vclist_setupGrid:  Grid lower corner = (-10.0802, 31.9498, 42.7458)
Vclist_assignAtoms:  Have 4173492 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 284.724
Vacc_storeParms:  Using 2814-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline1...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.550000
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.030000e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.100000e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 097)
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.840000e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.820000e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.848208e-01
Vprtstp: contraction number = 1.848208e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 3.095061e-02
Vprtstp: contraction number = 1.674628e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 6.639085e-03
Vprtstp: contraction number = 2.145058e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.695960e-03
Vprtstp: contraction number = 2.554508e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.144071e-04
Vprtstp: contraction number = 3.033133e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.635857e-04
Vprtstp: contraction number = 3.180081e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.068696e-05
Vprtstp: contraction number = 3.709797e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.195258e-05
Vprtstp: contraction number = 3.617346e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.313842e-06
Vprtstp: contraction number = 4.242711e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.623732e-06
Vprtstp: contraction number = 3.890695e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.645974e-06
Vprtstp: contraction number = 4.542207e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 6.608186e-07
Vprtstp: contraction number = 4.014757e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.241000e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.518000e+01
Vpmg_setPart:  lower corner = (-17.2455, 26.1685, 37.674)
Vpmg_setPart:  upper corner = (59.5545, 102.969, 114.474)
Vpmg_setPart:  actual minima = (-17.2455, 26.1685, 37.674)
Vpmg_setPart:  actual maxima = (59.5545, 102.969, 114.474)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.098000e+01
